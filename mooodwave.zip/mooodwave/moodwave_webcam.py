

import sys
import os
import cv2
import numpy as np
from tensorflow.keras.models import load_model
import pygame
import random
from PyQt6.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QComboBox
from PyQt6.QtCore import QTimer, Qt
from PyQt6.QtGui import QImage, QPixmap, QFont

BASE_DIR = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
# -----------------------------
# Load trained model
# -----------------------------
model_path = "C:/Users/malik/Documents/MoodWave/models/best_cnn_4emotions.h5"
model_path = os.path.join(BASE_DIR, "models", "best_cnn_4emotions.h5")



model = load_model(model_path)
emotions = ["Happiness", "Sadness", "Anger", "Neutral"]

# -----------------------------
# Initialize pygame mixer
# -----------------------------
pygame.mixer.init()

# -----------------------------
# Music setup
# -----------------------------
#music_folder = "C:/Users/malik/Documents/MoodWave/music"
music_folder = os.path.join(BASE_DIR, "music")
emotion_folder_map = {
    "Happiness": "happiness",
    "Sadness": "sadness",
    "Anger": "anger",
    "Neutral": "neutral"
}

# Load music files for each emotion
music_files = {}
for emotion, folder_name in emotion_folder_map.items():
    folder_path = os.path.join(music_folder, folder_name)
    if not os.path.exists(folder_path):
        print(f"Warning: Folder for {emotion} not found at {folder_path}")
        music_files[emotion] = []
        continue
    files = [os.path.join(folder_path, f) for f in os.listdir(folder_path) if f.endswith(".mp3")]
    if not files:
        print(f"Warning: No mp3 files found in {folder_path}")
    music_files[emotion] = files

current_emotion = None

def play_music(emotion):
    global current_emotion
    if emotion == current_emotion:
        return
    pygame.mixer.music.stop()
    if music_files[emotion]:
        song = random.choice(music_files[emotion])
        pygame.mixer.music.load(song)
        pygame.mixer.music.play(-1)
        current_emotion = emotion

def pause_music():
    pygame.mixer.music.pause()

def resume_music():
    pygame.mixer.music.unpause()

def stop_music():
    pygame.mixer.music.stop()

# -----------------------------
# GUI Application
# -----------------------------
class MoodWaveGUI(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MoodWave")
        self.setGeometry(100, 100, 900, 700)

        # Webcam label
        self.video_label = QLabel(self)
        self.video_label.setAlignment(Qt.AlignmentFlag.AlignCenter)

        # Detected emotion label
        self.emotion_label = QLabel("Detected Emotion: None", self)
        self.emotion_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.emotion_label.setFont(QFont("Arial", 16, QFont.Weight.Bold))

        # Music control buttons
        self.play_btn = QPushButton("Play Music", self)
        self.play_btn.clicked.connect(self.resume_music)

        self.pause_btn = QPushButton("Pause Music", self)
        self.pause_btn.clicked.connect(self.pause_music)

        self.stop_btn = QPushButton("Stop Music", self)
        self.stop_btn.clicked.connect(self.stop_music)

        # Manual emotion selection
        self.emotion_combo = QComboBox(self)
        self.emotion_combo.addItem("Auto Detect")
        self.emotion_combo.addItems(emotions)
        self.emotion_combo.currentTextChanged.connect(self.manual_emotion)

        # Exit button
        self.exit_btn = QPushButton("Exit", self)
        self.exit_btn.clicked.connect(self.close_app)

        # Layouts
        controls_layout = QHBoxLayout()
        controls_layout.addWidget(self.play_btn)
        controls_layout.addWidget(self.pause_btn)
        controls_layout.addWidget(self.stop_btn)
        controls_layout.addWidget(self.emotion_combo)
        controls_layout.addWidget(self.exit_btn)

        main_layout = QVBoxLayout()
        main_layout.addWidget(self.video_label)
        main_layout.addWidget(self.emotion_label)
        main_layout.addLayout(controls_layout)
        self.setLayout(main_layout)

        # Start webcam
        self.cap = cv2.VideoCapture(0)
        if not self.cap.isOpened():
            print("Error: Could not open webcam")
            sys.exit()

        # Timer to update frames
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

        # Manual override
        self.manual_mode = False
        self.manual_emotion_choice = None

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        # -----------------------------
        # Preprocess frame for model
        # -----------------------------
        img = cv2.resize(frame, (48, 48))
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = img / 255.0
        img = np.expand_dims(img, axis=0)

        # -----------------------------
        # Predict emotion
        # -----------------------------
        if not self.manual_mode:
            pred = model.predict(img, verbose=0)
            emotion = emotions[np.argmax(pred)]
        else:
            emotion = self.manual_emotion_choice

        # Update label and play music
        self.emotion_label.setText(f"Detected Emotion: {emotion}")
        play_music(emotion)

        # Display webcam frame
        cv2.putText(frame, emotion, (50, 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, (0, 255, 0), 2)
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = frame.shape
        bytes_per_line = ch * w
        qt_img = QImage(frame.data, w, h, bytes_per_line, QImage.Format.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(qt_img))

    def manual_emotion(self, text):
        if text == "Auto Detect":
            self.manual_mode = False
        else:
            self.manual_mode = True
            self.manual_emotion_choice = text

    def resume_music(self):
        resume_music()

    def pause_music(self):
        pause_music()

    def stop_music(self):
        stop_music()

    def close_app(self):
        stop_music()
        self.cap.release()
        cv2.destroyAllWindows()
        self.close()


# -----------------------------
# Run the GUI
# -----------------------------
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MoodWaveGUI()
    window.show()
    sys.exit(app.exec())
